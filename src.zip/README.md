# IntercambiaLibros

 -------------- COSAS POR REVISAR O TENER EN CUENTA -------------

1. sideBar.jsx tiene 2 comentarios para saber si mas adelante se deja asi o se incopora dentro de un GRID.