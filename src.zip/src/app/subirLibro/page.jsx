import FormSubirLibro from '@components/forms/formSubirLibro';

export default function Perfil() {
  return (
    <main className="container-fluid">
      <FormSubirLibro />
    </main>
  );
}
