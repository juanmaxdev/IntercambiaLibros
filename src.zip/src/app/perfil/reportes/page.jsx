import Reportes from '@components/perfil/reportes';

export default function Perfil() {
  return (
    <main className="container-fluid">
      <Reportes />
    </main>
  );
}
