import PerfilUser from '@components/perfil/perfilUser';

export default function Perfil() {
  return (
    <main className="container-fluid">
      <PerfilUser />
    </main>
  );
}
