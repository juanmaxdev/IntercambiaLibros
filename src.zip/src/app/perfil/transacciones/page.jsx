import Transaciones from '@components/perfil/transaciones';

export default function Perfil() {
  return (
    <main className="container-fluid">
      <Transaciones />
    </main>
  );
}
