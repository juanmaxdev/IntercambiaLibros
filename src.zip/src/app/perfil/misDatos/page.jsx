import FormDatosPerfil from '@components/forms/formDatosPerfil';
export default function MisDatos() {
  return (
    <main className="container-fluid">
      <FormDatosPerfil />
    </main>
  );
}
