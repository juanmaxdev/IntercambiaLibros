'use client';
import Mensajes from '@components/perfil/mensajes';

export default function MensajesPage() {
  return (
    <main className="container-fluid">
      <Mensajes />
    </main>
  );
}