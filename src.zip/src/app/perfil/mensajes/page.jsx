import Mensajes from '@components/perfil/mensajes';

export default function Perfil() {
  return (
    <main className="container-fluid">
      <Mensajes />
    </main>
  );
}
