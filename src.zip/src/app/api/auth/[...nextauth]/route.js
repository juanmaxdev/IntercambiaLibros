import { handlers } from "@/server/auth"

export const GET = handlers.GET
export const POST = handlers.POST
